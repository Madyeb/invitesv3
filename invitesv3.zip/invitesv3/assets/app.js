// assets/app.js

document.addEventListener("DOMContentLoaded", () => {
  const container = document.getElementById("app");
  if (!container) {
    console.error("No #app container found");
    return;
  }

  const kidId = container.dataset.kidId;
  if (!kidId || !KIDS || !KIDS[kidId]) {
    container.innerHTML = `
      <main class="main">
        <section class="card">
          <h2>Something went wrong</h2>
          <p class="helper">Kid configuration not found.</p>
        </section>
      </main>
    `;
    return;
  }

  const config = KIDS[kidId];
  document.title = config.pageTitle || "Birthday Party";

  renderPage(container, config);

  if (config.apiUrl) {
    setupForm(container, config.apiUrl);
    loadRsvps(container, config.apiUrl);
  } else {
    showNoApiMessage(container);
  }
});

function renderPage(container, config) {
  container.innerHTML = `
    <header class="hero">
      <div class="hero-inner">
        <p class="eyebrow">You are invited</p>
        <h1>${escapeHtml(config.pageTitle)}</h1>
        <p class="subtitle">
          ${escapeHtml(config.tagline)}
        </p>

        <section class="details">
          <p><strong>Date:</strong> ${escapeHtml(config.date)}</p>
          <p><strong>Time:</strong> ${escapeHtml(config.time)}</p>
          <p><strong>Location:</strong> ${escapeHtml(config.location)}</p>
        </section>
      </div>
    </header>

    <main class="main">
      <section class="card card-form">
        <h2>RSVP</h2>
        <p class="helper">
          Please let us know who is coming.
        </p>

        <form id="rsvp-form">
          <div class="field">
            <label for="guestName">Guest name<span class="required">*</span></label>
            <input id="guestName" name="guestName" required />
          </div>

          <div class="field field-inline">
            <div>
              <label for="numberOfAdults">Number of adults</label>
              <input id="numberOfAdults" name="numberOfAdults" type="number" min="0" inputmode="numeric" />
            </div>
            <div>
              <label for="numberOfChildren">Number of children</label>
              <input id="numberOfChildren" name="numberOfChildren" type="number" min="0" inputmode="numeric" />
            </div>
          </div>

          <div class="field">
            <label for="attending">Attending</label>
            <select id="attending" name="attending">
              <option value="Yes">Yes</option>
              <option value="No">No</option>
              <option value="Maybe">Maybe</option>
            </select>
          </div>

          <div class="field">
            <label for="contactEmail">Contact email</label>
            <input id="contactEmail" name="contactEmail" type="email" />
          </div>

          <div class="field">
            <label for="notes">Food allergies or notes</label>
            <textarea id="notes" name="notes" rows="3"></textarea>
          </div>

          <div class="form-status">
            <span data-role="form-message"></span>
          </div>

          <button type="submit" class="btn primary">
            Submit RSVP
          </button>
        </form>
      </section>

      <section class="card">
        <h2>Guest list</h2>
        <p class="helper">
          This updates from the RSVP sheet.
        </p>

        <div class="status status-loading" data-role="rsvp-loading">
          Loading RSVPs...
        </div>
        <div class="status status-error" data-role="rsvp-error" hidden>
          There was a problem loading the RSVP list.
        </div>

        <div class="table-wrapper" data-role="rsvp-table-wrapper" hidden>
          <table class="rsvp-table">
            <thead>
              <tr>
                <th>Guest</th>
                <th>Adults</th>
                <th>Children</th>
                <th>Attending</th>
                <th>Notes</th>
              </tr>
            </thead>
            <tbody data-role="rsvp-tbody">
              <!-- Filled by JS -->
            </tbody>
          </table>
        </div>
      </section>
    </main>

    <footer class="footer">
      <p>Made with ❤️ by Madye, powered by Google Sheets and GitHub Pages.</p>
    </footer>
  `;
}

function setupForm(container, apiUrl) {
  const form = container.querySelector("#rsvp-form");
  const messageEl = container.querySelector('[data-role="form-message"]');

  if (!form) return;

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!apiUrl) return;

    const formData = new FormData(form);
    const payload = {
      guestName: formData.get("guestName") || "",
      numberOfAdults: formData.get("numberOfAdults") || "",
      numberOfChildren: formData.get("numberOfChildren") || "",
      attending: formData.get("attending") || "",
      contactEmail: formData.get("contactEmail") || "",
      notes: formData.get("notes") || ""
    };

    if (!payload.guestName.trim()) {
      if (messageEl) {
        messageEl.textContent = "Please enter a guest name.";
        messageEl.className = "form-message error";
      }
      return;
    }

    if (messageEl) {
      messageEl.textContent = "Submitting...";
      messageEl.className = "form-message";
    }

    try {
      const res = await fetch(apiUrl, {
        method: "POST",
        headers: {
          "Accept": "application/json",
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });

      let ok = res.ok;
      let json = null;
      try {
        json = await res.json();
      } catch (_) {
        // response might not be JSON
      }

      if (!ok || (json && json.error)) {
        const msg = (json && json.error) || "There was a problem submitting your RSVP.";
        if (messageEl) {
          messageEl.textContent = msg;
          messageEl.className = "form-message error";
        }
        return;
      }

      if (messageEl) {
        messageEl.textContent = "Thank you, your RSVP has been recorded.";
        messageEl.className = "form-message success";
      }

      form.reset();
      const attendingSelect = form.querySelector("#attending");
      if (attendingSelect) {
        attendingSelect.value = "Yes";
      }

      loadRsvps(container, apiUrl);
    } catch (err) {
      console.error("RSVP submit error:", err);
      if (messageEl) {
        messageEl.textContent = "There was a problem submitting your RSVP.";
        messageEl.className = "form-message error";
      }
    }
  });
}

async function loadRsvps(container, apiUrl) {
  const loadingEl = container.querySelector('[data-role="rsvp-loading"]');
  const errorEl = container.querySelector('[data-role="rsvp-error"]');
  const tableWrapper = container.querySelector('[data-role="rsvp-table-wrapper"]');
  const tableBody = container.querySelector('[data-role="rsvp-tbody"]');

  try {
    const res = await fetch(apiUrl, {
      method: "GET",
      headers: { "Accept": "application/json" }
    });

    if (!res.ok) {
      throw new Error("Network response was not ok");
    }

    const json = await res.json();
    const rows = Array.isArray(json.data) ? json.data : [];

    if (loadingEl) loadingEl.hidden = true;
    if (errorEl) errorEl.hidden = true;
    if (tableWrapper) tableWrapper.hidden = false;
    if (!tableBody) return;

    tableBody.innerHTML = "";

    if (rows.length === 0) {
      const tr = document.createElement("tr");
      const td = document.createElement("td");
      td.colSpan = 5;
      td.textContent = "No RSVPs yet.";
      td.style.color = "#666";
      tr.appendChild(td);
      tableBody.appendChild(tr);
      return;
    }

    rows.forEach(row => {
      const tr = document.createElement("tr");

      const guest = row.guest_name || "";
      const adults = row.number_of_adults || "";
      const children = row.number_of_children || "";
      const attending = row.attending || "";
      const notes = row.food_allergies_notes || "";

      tr.innerHTML = `
        <td>${escapeHtml(String(guest))}</td>
        <td>${escapeHtml(String(adults))}</td>
        <td>${escapeHtml(String(children))}</td>
        <td>${escapeHtml(String(attending))}</td>
        <td>${escapeHtml(String(notes))}</td>
      `;

      tableBody.appendChild(tr);
    });
  } catch (err) {
    console.error("Error loading RSVPs:", err);
    if (loadingEl) loadingEl.hidden = true;
    if (errorEl) errorEl.hidden = false;
    if (tableWrapper) tableWrapper.hidden = true;
  }
}

function showNoApiMessage(container) {
  const loadingEl = container.querySelector('[data-role="rsvp-loading"]');
  const errorEl = container.querySelector('[data-role="rsvp-error"]');
  const tableWrapper = container.querySelector('[data-role="rsvp-table-wrapper"]');
  const tableBody = container.querySelector('[data-role="rsvp-tbody"]');

  if (loadingEl) loadingEl.hidden = true;
  if (tableWrapper) tableWrapper.hidden = false;
  if (errorEl) errorEl.hidden = true;

  if (tableBody) {
    tableBody.innerHTML = "";
    const tr = document.createElement("tr");
    const td = document.createElement("td");
    td.colSpan = 5;
    td.textContent = "RSVP data source is not configured yet.";
    td.style.color = "#666";
    tr.appendChild(td);
    tableBody.appendChild(tr);
  }
}

function escapeHtml(str) {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
