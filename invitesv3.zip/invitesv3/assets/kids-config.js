// assets/kids-config.js

const KIDS = {
  leslie: {
    id: "leslie",
    displayName: "Leslie",
    pageTitle: "Leslie's Birthday Party",
    tagline: "Come flip, jump, and celebrate with Leslie at the gym.",
    date: "March 15, 2026",
    time: "10:00 AM (Eastern)",
    location: "Gold Medal Gymnastics, E. Pulaski Rd, Greenlawn, New York",
    rsvpUrl: null, // site itself is the form
    apiUrl: "https://script.google.com/macros/s/AKfycbwWvHxO3LJbV8iuqE4rz2qJjApNHuCfqzJmSNMdhMmZHicnIE7qn3AAc-_hjEA3E9CcJQ/exec"
  }
};
