// main.js

function getPartyIdFromUrl() {
  const params = new URLSearchParams(window.location.search);
  const partyParam = params.get("party");
  if (partyParam && PARTIES[partyParam]) return partyParam;
  return PARTIES.defaultPartyId || "leslie";
}

function applyTheme(config) {
  const root = document.documentElement;
  root.style.setProperty("--accent", config.accentColor);
  root.style.setProperty("--accent-secondary", config.secondaryColor);
  root.style.setProperty("--bg", config.backgroundColor);
}

function setupHero(config) {
  const heroImg = document.getElementById("hero-image");
  const kicker = document.getElementById("hero-kicker");
  const title = document.getElementById("hero-title");
  const subtitle = document.getElementById("hero-subtitle");

  heroImg.src = config.heroImage;
  heroImg.alt = `${config.childName}'s birthday invite`;

  kicker.textContent = `${config.childName}'s birthday party`;
  title.textContent = `${config.childName} is turning ${config.age}!`;
  subtitle.textContent = "You are invited to celebrate with us.";
}

function setupDetails(config) {
  const d = config.details;

  document.getElementById("details-date-time").textContent =
    `${d.dateLabel} · ${d.timeLabel}`;

  document.getElementById("details-location").textContent =
    d.venueName;

  document.getElementById("details-address").textContent =
    d.addressLine;

  const notesUl = document.getElementById("details-notes");
  notesUl.innerHTML = "";
  d.notes.forEach((note) => {
    const li = document.createElement("li");
    li.textContent = note;
    notesUl.appendChild(li);
  });

  const btn = document.getElementById("add-to-calendar-btn");
  btn.addEventListener("click", () => downloadIcs(config.calendar));
}

function generateSessionId() {
  if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
  return "session-" + Math.random().toString(36).slice(2, 10);
}

/* RSVP form logic */

let attendees = [];
let currentRsvpChoice = "yes";

function renderAttendees() {
  const list = document.getElementById("attendees-list");
  list.innerHTML = "";

  attendees.forEach((att, index) => {
    const row = document.createElement("div");
    row.className = "attendee-row";

    const nameInput = document.createElement("input");
    nameInput.type = "text";
    nameInput.placeholder = index === 0 ? "Child's name" : "Name";
    nameInput.value = att.name;
    nameInput.addEventListener("input", (e) => {
      attendees[index].name = e.target.value;
    });

    const typeSelect = document.createElement("select");
    ["", "Child", "Adult"].forEach((opt) => {
      const optionEl = document.createElement("option");
      optionEl.value = opt.toLowerCase();
      optionEl.textContent = opt || "Type";
      if (att.type === opt.toLowerCase()) optionEl.selected = true;
      typeSelect.appendChild(optionEl);
    });
    typeSelect.addEventListener("change", (e) => {
      attendees[index].type = e.target.value;
    });

    const allergyInput = document.createElement("input");
    allergyInput.type = "text";
    allergyInput.placeholder = "Allergies (optional)";
    allergyInput.value = att.allergies;
    allergyInput.addEventListener("input", (e) => {
      attendees[index].allergies = e.target.value;
    });

    const removeBtn = document.createElement("button");
    removeBtn.type = "button";
    removeBtn.className = "attendee-remove-btn";
    removeBtn.textContent = "×";
    removeBtn.addEventListener("click", () => {
      if (attendees.length > 1) {
        attendees.splice(index, 1);
        renderAttendees();
      }
    });

    row.appendChild(nameInput);
    row.appendChild(typeSelect);
    row.appendChild(allergyInput);
    row.appendChild(removeBtn);

    list.appendChild(row);
  });
}

function setupRsvpForm(partyConfig) {
  const form = document.getElementById("rsvp-form");
  const choiceInputs = form.elements["rsvpChoice"];
  const attendeesWrapper = document.getElementById("attendees-wrapper");
  const addAttendeeBtn = document.getElementById("add-attendee-btn");
  const groupChildNameInput = document.getElementById("group-child-name");
  const confirmationEl = document.getElementById("rsvp-confirmation");

  attendees = [
    { name: "", type: "child", allergies: "" }
  ];
  renderAttendees();

  function updateRsvpChoice() {
    const selected = Array.from(choiceInputs).find((i) => i.checked);
    currentRsvpChoice = selected ? selected.value : "yes";

    if (currentRsvpChoice === "yes") {
      attendeesWrapper.style.display = "";
      addAttendeeBtn.disabled = false;
    } else {
      attendeesWrapper.style.display = "none";
      addAttendeeBtn.disabled = true;
    }
  }

  Array.from(choiceInputs).forEach((input) => {
    input.addEventListener("change", updateRsvpChoice);
  });
  updateRsvpChoice();

  addAttendeeBtn.addEventListener("click", () => {
    attendees.push({ name: "", type: "", allergies: "" });
    renderAttendees();
  });

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    confirmationEl.textContent = "";

    const childName = groupChildNameInput.value.trim();
    if (!childName) {
      groupChildNameInput.focus();
      return;
    }

    const sessionId = generateSessionId();
    const partyId = partyConfig.partyId;
    const rsvp = currentRsvpChoice;
    const groupKey = childName;

    let finalAttendees = [];
    if (rsvp === "yes") {
      finalAttendees = attendees
        .map((a, index) => ({
          attendeeId: "A" + (index + 1),
          name: a.name.trim(),
          type: a.type || "",
          allergies: a.allergies.trim()
        }))
        .filter((a) => a.name.length > 0);
      if (!finalAttendees.length) {
        // if no names entered in rows, at least include childName
        finalAttendees.push({
          attendeeId: "A1",
          name: childName,
          type: "child",
          allergies: ""
        });
      }
    } else {
      // simple decline, store just the child name
      finalAttendees = [
        {
          attendeeId: "A1",
          name: childName,
          type: "child",
          allergies: ""
        }
      ];
    }

    const payload = {
      partyId,
      sessionId,
      rsvp,
      groupKey,
      childName,
      attendees: finalAttendees
    };

    // For now, just log it and show confirmation.
    // Later you will send this to your Google Apps Script endpoint.
    console.log("RSVP payload:", payload);
    sendRsvpToSheet(payload, partyConfig)
      .then(() => {
        const name = partyConfig.childName;
        if (rsvp === "yes") {
          confirmationEl.textContent =
            `Thank you. ${name} cannot wait to celebrate with you. 🎉`;
        } else {
          confirmationEl.textContent = "We will miss you so much. 💕";
        }
        loadGuestList(partyConfig);
      })
      .catch((err) => {
        console.error("RSVP error:", err);
        confirmationEl.textContent =
          "Something went wrong submitting your RSVP. Please try again.";
      });
  });
}

/* Placeholder for sending RSVP to Google Sheets */

async function sendRsvpToSheet(payload, partyConfig) {
  const endpoint = PARTIES.rsvpEndpoint;
  if (!endpoint || endpoint === "YOUR_APPS_SCRIPT_URL_HERE") {
    // In dev, just resolve immediately.
    return Promise.resolve();
  }

  const response = await fetch(endpoint, {
    method: "POST",
    mode: "cors",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  });

  if (!response.ok) {
    throw new Error("RSVP submit failed");
  }

  return response.json();
}

/* Guest list loading (placeholder) */

async function loadGuestList(partyConfig) {
  const container = document.getElementById("guest-list-content");
  container.innerHTML = "Loading guest list...";

  const endpoint = PARTIES.rsvpEndpoint;
  if (!endpoint || endpoint === "YOUR_APPS_SCRIPT_URL_HERE") {
    container.textContent =
      "Guest list will appear here once the Google Sheet connection is set up.";
    return;
  }

  const url = `${endpoint}?partyId=${encodeURIComponent(
    partyConfig.partyId
  )}&mode=guestList`;

  const response = await fetch(url, { method: "GET", mode: "cors" });
  if (!response.ok) {
    container.textContent = "Could not load guest list.";
    return;
  }

  const data = await response.json();
  /*
    Expected data format example:
    [
      {
        sessionId: "...",
        groupKey: "Leslie",
        rsvp: "yes",
        attendees: [
          { name: "Leslie", type: "child", allergies: "Peanut" },
          { name: "Harrison", type: "adult", allergies: "" }
        ]
      },
      ...
    ]
  */

  renderGuestList(container, data);
}

function renderGuestList(container, sessions) {
  container.innerHTML = "";

  const yesSessions = sessions.filter((s) => s.rsvp === "yes");
  if (!yesSessions.length) {
    container.textContent = "No guests have RSVP'd yes yet.";
    return;
  }

  yesSessions.forEach((session) => {
    const card = document.createElement("div");
    card.className = "guest-group-card";

    const titleEl = document.createElement("p");
    titleEl.className = "guest-group-title";
    titleEl.textContent = session.groupKey;
    card.appendChild(titleEl);

    const ul = document.createElement("ul");
    ul.className = "guest-group-list";

    session.attendees.forEach((a) => {
      const li = document.createElement("li");
      const typeLabel = a.type === "child" ? "child" : a.type === "adult" ? "adult" : "";
      li.textContent = typeLabel
        ? `${a.name} (${typeLabel})`
        : a.name;
      if (a.allergies) {
        li.textContent += ` – allergies: ${a.allergies}`;
      }
      ul.appendChild(li);
    });

    card.appendChild(ul);
    container.appendChild(card);
  });
}

/* Calendar file (ICS) download */

function downloadIcs(calendarConfig) {
  const { title, description, start, end, timeZone, location } = calendarConfig;

  function formatIcsDate(dt) {
    // convert local ISO without offset into UTC naive format YYYYMMDDTHHMMSSZ
    const date = new Date(dt + "Z");
    const pad = (n) => String(n).padStart(2, "0");
    return (
      date.getUTCFullYear().toString() +
      pad(date.getUTCMonth() + 1) +
      pad(date.getUTCDate()) +
      "T" +
      pad(date.getUTCHours()) +
      pad(date.getUTCMinutes()) +
      pad(date.getUTCSeconds()) +
      "Z"
    );
  }

  const dtStart = formatIcsDate(start);
  const dtEnd = formatIcsDate(end);

  const icsLines = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//Madye Birthday//Invite//EN",
    "BEGIN:VEVENT",
    `UID:${Math.random().toString(36).slice(2)}@madye-invite`,
    `DTSTAMP:${dtStart}`,
    `DTSTART:${dtStart}`,
    `DTEND:${dtEnd}`,
    `SUMMARY:${title}`,
    `DESCRIPTION:${description.replace(/\r?\n/g, "\\n")}`,
    `LOCATION:${location}`,
    "END:VEVENT",
    "END:VCALENDAR"
  ];

  const blob = new Blob([icsLines.join("\r\n")], {
    type: "text/calendar;charset=utf-8"
  });

  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${title.replace(/\s+/g, "-").toLowerCase()}.ics`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/* Confetti */

function setupConfetti(config) {
  if (!config.confettiEnabled) return;
  const prefersReduced = window.matchMedia &&
    window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (prefersReduced) return;

  const colors = [
    config.accentColor,
    config.secondaryColor,
    "#CFA2E8",
    "#FCE58D",
    "#A8E6CF"
  ];

  const layer = document.querySelector(".confetti-layer");
  const dotCount = 28;

  for (let i = 0; i < dotCount; i++) {
    const dot = document.createElement("div");
    dot.className = "confetti-dot";
    const size = Math.random() * 7 + 4;
    dot.style.width = `${size}px`;
    dot.style.height = `${size}px`;
    dot.style.backgroundColor = colors[i % colors.length];
    dot.style.left = `${Math.random() * 100}%`;
    dot.style.bottom = `${Math.random() * 100}%`;
    const duration = 10 + Math.random() * 10;
    const delay = Math.random() * -duration;
    dot.style.animationDuration = `${duration}s`;
    dot.style.animationDelay = `${delay}s`;
    layer.appendChild(dot);
  }
}

/* Init */

document.addEventListener("DOMContentLoaded", () => {
  const partyId = getPartyIdFromUrl();
  const partyConfig = PARTIES[partyId];

  applyTheme(partyConfig);
  setupHero(partyConfig);
  setupDetails(partyConfig);
  setupRsvpForm(partyConfig);
  setupConfetti(partyConfig);

  // If you want guest list to show right away, you can call this here.
  // For now, it will at least show the placeholder message.
  loadGuestList(partyConfig);
});
