// config.js

const PARTIES = {
  leslie: {
    partyId: "leslie",
    childName: "Leslie",
    age: 5,
    //heroImage: "assets/leslie-hero.jpg", // replace with your real image path
    accentColor: "#F7A8B8", // ballet pink
    secondaryColor: "#7FC8F8", // sky blue
    backgroundColor: "#FFF8F3",
    confettiEnabled: true,

    details: {
      dateLabel: "Saturday, March 15",
      timeLabel: "10:00 AM to 11:30 AM EST",
      venueName: "Gold Medal Gymnastics",
      locationLabel: "Gold Medal Gymnastics Center",
      addressLine: "266 Pulaski Rd, Greenlawn, NY",
      notes: [
        "Coffee and light snacks will be waiting for grown ups.
        Leslie has requested plain and rainbow bagels be served (egg free).
        Please let us know if you have any allergies."
      ]
    },

    calendar: {
      title: "Leslie's 5th Birthday Party",
      description:
        "Leslie's birthday party",
      start: "2026-03-15T10:00:00",
      end: "2026-03-15T11:30:00",
      timeZone: "America/New_York",
      location: "Gold Medal Gymnastics Center, 266 Pulaski Rd, Greenlawn, NY, 11740"
    },

    gifting: {
      primary529: {
        label: "College savings for Leslie",
        description:
          "If you would like to celebrate with a gift, a contribution to Leslie's future education is a huge help.",
        // replace with real UGift link when you have it
        link: ""
      },
      wishlists: [
        {
          label: "Amazon wishlist",
          link: ""
        },
        {
          label: "Target wishlist",
          link: ""
        }
      ]
    }
  },

  dean: {
    partyId: "dean",
    childName: "Dean",
    age: 2,
    heroImage: "assets/dean-hero.jpg",
    accentColor: "#84B6F4", // cornflower blue
    secondaryColor: "#FFD97D", // goldenrod
    backgroundColor: "#FFF9F4",
    confettiEnabled: true,

    details: {
      dateLabel: "Saturday, April 18",
      timeLabel: "10:00 AM to 11:30 AM EST",
      venueName: "A Latte Fun",
      locationLabel: "A Latte Fun · Huntington, NY",
      addressLine: "Huntington, NY",
      notes: [
        "Socks required for kids in the play area.",
        "Coffee and treats for adults will be available while the kids play."
      ]
    },

    calendar: {
      title: "Dean's 2nd Birthday Party",
      description:
        "Dean's birthday party at A Latte Fun. Socks required for kids. Coffee and treats for adults.",
      start: "2026-04-18T10:00:00",
      end: "2026-04-18T11:30:00",
      timeZone: "America/New_York",
      location: "A Latte Fun, Huntington, NY"
    },

    gifting: {
      primary529: {
        label: "College savings for Dean",
        description:
          "If you would like to celebrate with a gift, a contribution to Dean's future education is greatly appreciated.",
        link: ""
      },
      wishlists: [
        {
          label: "Amazon wishlist",
          link: ""
        }
      ]
    }
  },

  defaultPartyId: "leslie",

  // placeholder for your future Google Apps Script endpoint
  rsvpEndpoint: "https://script.google.com/macros/s/AKfycbwWvHxO3LJbV8iuqE4rz2qJjApNHuCfqzJmSNMdhMmZHicnIE7qn3AAc-_hjEA3E9CcJQ/exec"
};
